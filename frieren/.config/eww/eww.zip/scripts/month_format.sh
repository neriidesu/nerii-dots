#!/bin/bash


# Get the month.
month=$(date +"%b")

# Return the month string.
echo "$month"
