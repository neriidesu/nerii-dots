#!/bin/bash

title=$(playerctl metadata xesam:title -p spotify)

echo "${title}"